"""Claude turn helpers."""
